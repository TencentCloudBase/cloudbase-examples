module.exports = {
  "appName":"深圳美食图鉴",
  "mtaAppID": "500668228",
  "mtaEventID":"500668246",
  "envID":"demo-3ee737",
  "mapSubKey":"URTBZ-FLY64-OVLUX-XHH4A-5DOGO-YKFFP",
  "center_longitude": 113.921736,
  "center_latitude": 22.538017,
  "dynamic_title":true,
  "show_admin":false,
  "default_scale":16
}