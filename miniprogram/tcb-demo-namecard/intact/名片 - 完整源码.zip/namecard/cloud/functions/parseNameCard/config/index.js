module.exports = {
  AppId: '1251005156',
  SecretId: 'AKIDWQYynaz2vw4bZbp2veO6TzN3PrInwb9M',
  SecretKey: 'zAN5JHapArCttgpoHXiTmgRsl9mC2MTm'
};