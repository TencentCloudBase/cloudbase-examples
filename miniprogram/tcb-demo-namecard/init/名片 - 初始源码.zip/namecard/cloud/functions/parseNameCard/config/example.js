module.exports = {
  AppId: '',
  SecretId: '',
  SecretKey: ''
};