const { ImageClient } = require('image-node-sdk');
const {
  AppId,
  SecretId,
  SecretKey
} = require('./config/index.js');
