//获取应用实例
const app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {

  },
  
  /**
   * 获取文章列表数据
   */
  getData() {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.getData();
  },

  /**
   * 跳转至名片详情
   */
  getDetail(e) {
    
  }

})