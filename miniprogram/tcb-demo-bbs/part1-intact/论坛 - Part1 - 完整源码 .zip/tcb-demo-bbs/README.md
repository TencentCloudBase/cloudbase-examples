# 论坛小程序案例

基于小程序·云开发的论坛小程序DEMO

## 注意事项
- 教程在：[小程序·云开发系列教程](https://github.com/TencentCloudBase/mp-book)
- 打开的时候记得填写 `project.config.json` 中的 `appid` 字段，其它功能的试用，请参考教程里的[小程序中级场景及开发教学](https://github.com/TencentCloudBase/mp-book/blob/master/medium-tutorial/ai.md) 进行配置试用。

### 下载或clone代码包
```javascript
git clone https://github.com/TencentCloudBase/tcb-demo-bbs.git
```

## 体验
点击小程序开发IDE中的“预览”，用微信扫一扫即可体验.

