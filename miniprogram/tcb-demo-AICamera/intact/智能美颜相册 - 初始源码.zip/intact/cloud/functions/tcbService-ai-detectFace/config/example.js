module.exports = {
  SecretID: '',
  SecretKey: ''
};